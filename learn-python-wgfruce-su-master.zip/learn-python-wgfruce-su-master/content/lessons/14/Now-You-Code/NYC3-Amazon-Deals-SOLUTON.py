'''
Now You Code 3: Amazon Deals

Create a program that downloads and prints Today's Deals from amazon.com (https://www.amazon.com/gp/goldbox)

Hint: You will need to use selenium to scrape this page, it is loaded with JavaScript!

Example Run:

Here are Amazon.com deals!
1.) Shower Hose 79 inch (6.5 Ft.) for Hand Held Showerhead                $8.72
2.) Streamlight 88851 PolyTac LED Flashlight with Lithium Battery         $30.52
....
....
....

Start out your program by writing your TODO list of steps
you'll need to solve the problem!
'''

# TODO: Write Todo list then beneath write your code


# Write code here 
