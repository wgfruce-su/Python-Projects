'''
Now You Code 3: Large Initials

Write a python program to display your initials as "Large Letters"
The program should take no input and only display your initials.
For example, mine are:

X     X  XXXXXX
X X X X  X
X  X  X  XXX
X     X  X
X     X  X

The goal of this program is for your to get your bearings writing code
using the print() statement
'''

