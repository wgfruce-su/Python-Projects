'''
Now You Code 4: Mad-Libs!

Write a Python program which creates your own unique Mad-Libs! story.

If you are not familar with a Mad-Libs! story, check out:
http://www.madlibs.com and http://www.madtakes.com

Your story should take at least 5 inputs, and should include more than
once sentence. 
'''
noun1 = input('noun1 ')
noun2 = input('noun2 ')
verb1 = input('verb1 ')
verb2 = input('verb2 ')
noun3 = input('noun3 ')

# The stroy:
print('At the ',noun1, 'a', noun2, verb1, 'up a watermelon, and', verb2,' it acrose the', noun3, '.')
