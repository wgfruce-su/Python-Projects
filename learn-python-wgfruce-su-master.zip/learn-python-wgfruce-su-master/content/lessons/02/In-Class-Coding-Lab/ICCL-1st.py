# This is my 1st Python program from IDLE

