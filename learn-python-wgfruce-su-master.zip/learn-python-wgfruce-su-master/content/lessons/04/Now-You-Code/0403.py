try:
    grade = int(input("Enter your current points earned in IST256"))

    if grade >= 570:
        print("Grade: A")
        
    elif 540< grade < 570:
        print("Grade: A-")
        
    elif 510< grade < 540:
        print("Grade: B+")
        
    elif 480< grade < 510:
        print("Grade: B")
        
    elif 450< grade < 480:
        print("Grade: B-")
        
    elif 420< grade < 450:
        print("Grade: C+")
        
    elif 390< grade < 420:
        print("Grade: C")
        
    elif 360< grade < 390:
        print("Grade: C-")
        
    elif 300< grade < 360:
        print("Grade: D")
        
    elif 0 < grade < 300:
        print("Grade: F")
        
    else:
        print("Not a valid grade!!!")
 
except:
    print("Please enter a vaid number!")
