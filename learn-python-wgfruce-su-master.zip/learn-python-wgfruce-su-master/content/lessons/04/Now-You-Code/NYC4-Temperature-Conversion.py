'''
Now You Code 4: Temperature Conversion

Write a Python program to input a temperature in Fahrenheit or Celcius,
then converts it to the other unit. The program should first input a temperature
then input a unit of C or F. It should then convert the temperature to the
other unit. 

After you get it working initially, re-write it to handle bad input. 

Example Run 1:

    Enter temperature: 212
    In which units C or F? F
    That's 100.0 C

Example Run 2:

    Enter temperature: 0
    In which units C or F? C
    That's 32.0 F

NOTE: You can find the formulas online.

Start out your program by writing your TODO list of steps
you'll need to solve the problem!
'''

# TODO: List 


# TODO Write code here



