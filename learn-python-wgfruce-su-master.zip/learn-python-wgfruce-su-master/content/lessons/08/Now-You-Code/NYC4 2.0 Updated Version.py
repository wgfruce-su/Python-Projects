'''
Now You Code 4: Email Harvesting Training

Description

Write a program to extract the email addresses from the mailbox
file "NYC4-mbox-short.txt" and save them into another file
"NYC4-emails.txt" with one extracted email address per line.

The best way to find the emails in the mailbox file is to search
for lines in the file that begin with "From:". When you find an email
write just the address (not "From:" and the address) to
"NYC4-emails.txt", and don't worry about duplicates.

The program should print the number of emails it wrote to the file.

Example Run:

Wrote 27 emails to NYC4-emails.txt


Start out your program by writing your TODO list of steps
you'll need to solve the problem!
'''

# TODO: Write Todo list then beneath write your code
# define linecount of email and total confidence
# open a file to handle the emails
# have program read email from file
# next let the open file be written in from input

# Write code here 
file_name_1 = "NYC4-mbox-short.txt"
file_name_2 = "NYC4-emails.txt"
count = 0

with open (file_name_1, 'r') as inf:
    with open (file_name_2, 'w') as outf:
        for line in inf.readlines():
            if line.startswith('From: '):
                temp_email = (line.strip())
                replacement = line.replace("From: " , "")
                outf.write(replacement)
                count = count + 1
print("Wrote", count, "emails to NYC-emails.txt")
