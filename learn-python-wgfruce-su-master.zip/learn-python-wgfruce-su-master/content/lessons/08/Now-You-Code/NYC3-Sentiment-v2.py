'''
Now You Code 3: Sentiment 2.0

Let's improve on our basic sentiment analyzer in Python.

Copy the code from 1.0 most of it will be the same.

We will improve on this program by writing a user-defined
function load_words() to load the positve or negative words from a file.

For example, instead of:

pos = "happy glad joy"

we do this:

pos = load_words("NYC3-pos.txt")

We can now make the program "smarter" simply by adding positive and
negative words to the text files!


#### bad hate dislike horrible stinks awful slow clueless useless dumb sad
#### good love like great wonderful fast helpful smart friendly happy joy
'''

# TODO: Write Todo list then beneath write your code
# Write code here
#define variable
def load_words(file):
  
#read file
    with open(file, 'r') as f:
        string = f.read()
        words = string.split()
    return words

#assign files
file1 = 'NYC3-pos.txt'
file2 = 'NYC3-neg.txt'

print("Sentiment Analyzer 2.56\nType 'quit' to exit.")
text = input("Enter text: ")

positive_words = load_words(file1)
negative_words = load_words(file2)
t_text = text.split()
score = 0
for text_word in t_text:

    for search_word in positive_words:
        if search_word == text_word:
            score = score + 1
      
    for search_word in negative_words:
        if search_word == text_word:
            score = score - 1

#Used to find if the sentence is neutral, positive, negative
if text == "quit":
    print("Thank you")
if score == 0:
    print(score, 'neutral')
elif score > 0:
    print(score, 'positive')
elif score < 0:
    print(score, 'negative')
