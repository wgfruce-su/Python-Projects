'''
Now You Code 4: Email Harvesting Training

Description

Write a program to extract the email addresses from the mailbox
file "NYC4-mbox-short.txt" and save them into another file
"NYC4-emails.txt" with one extracted email address per line.

The best way to find the emails in the mailbox file is to search
for lines in the file that begin with "From:". When you find an email
write just the address (not "From:" and the address) to
"NYC4-emails.txt", and don't worry about duplicates.

The program should print the number of emails it wrote to the file.

Example Run:

Wrote 27 emails to NYC4-emails.txt


Start out your program by writing your TODO list of steps
you'll need to solve the problem!
'''

# TODO: Write Todo list then beneath write your code
# define linecount of email and total confidence
# open a file to handle the emails
# have program read email from file
# next let the open file be written in from input

# Write code here 
import re
line_count = 0
total_confidence = 0

#read part of file
file_name = "NYC4-mbox-short.txt"
with open(file_name, 'r') as f:
    id = []
    for line in f.readlines():
        
        if line.startswith("From: "):
            id.append(line[6:])
            
#write part of file            
thefile = open('NYC4-emails.txt', 'w')
for item in id:
    thefile.write("%s/n" %item)
    
#count and print of the email number
numberemails = len(id)
print ("Wrote", numberemails, "emails to NYC4-emails.txt")
