# TODO: Write Todo list then beneath write your code
#Import math
#Input te given varialbes
#Calcualte the area and circumfrence
#Debug code from other inputes
#Print Circumfrence and Area

#Area = pie * r^2
#Circumfrence = 2 * pie * r

# Write code here
import math
def Area(r):
    Area = (math.pi * r**2)
    return Area

def Circumfrence(r):
    Circumfrence = (2 * math.pi * r)
    return Circumfrence

while True:    
    try:  
        r = int(input('Enter the radius of the circle: '))
        break
    except ValueError:
        print('Please enter a number')
        
if r >= 0:

    print('A circle with a radius: %.3f' % r, 'has a')
    print('Circumfrence of: %.3f' % Circumfrence(r))
    print('and an Area of: %.3f' % Area(r))

else:
    print('Print enter a number greater than 0')
