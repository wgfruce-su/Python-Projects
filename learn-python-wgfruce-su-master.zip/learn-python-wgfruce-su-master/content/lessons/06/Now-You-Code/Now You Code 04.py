# TODO: Write Todo list then beneath write your code
#Define the Function
#Input a character
#Input a text
#Loop Characters the amount is necessary
#Output the number of character's found in the text

# Write code here 
character = input("Enter a character: ")
text_string = input("Enter a text: ")
loop_count = 0

for z in text_string:
    if character == z:
        loop_count += 1

print("The character %s appears %d times in the text." % (character, loop_count))
