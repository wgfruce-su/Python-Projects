'''
Now You Code 3: Twitter Hashtag Detector

Let's write a program which extracts the twitter hashtags from the text.

Example Run 1:

    Enter Tweet: You got a 50 on the exam? #iamsad for you!
    Hashtag: #iamsad
    
Example Run 2:

    Enter Tweet: #lol too funny #joke #haha
    Hashtag: #lol
    Hashtag: #joke
    Hashtag: #haha

Example Run 3:

    Enter Tweet: Happy birthday @mafudge
    Hashtag: none

HINT: to handle the 3rd case you must keep a runnning count of hashtags
you find in the Tweet.


As usual, start out your program by writing your TODO list of steps
you'll need to solve the problem!
'''

# TODO: Write Todo list then beneath write your code
#input a tweet
#check a hashtag
#get rid of the hashtags
#write about the hashtag

# Write code here
print('Twitter Hashtag Detector!')
count = 0
tweet = input('Enter tweet: ')
hashtag = [tag[0:] for tag in tweet.split() if tag.startswith('#')]

for tag in hashtag:
    count = tweet.count('#')
    print('Hashtag: ',tag)
if count == 0:
    print('Hashtag: None!')
    
