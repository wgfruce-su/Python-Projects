'''
Now You Code 4: Exam Scores

In this example, write a program to load the exam-scores data set here: https://raw.githubusercontent.com/mafudge/datasets/master/exam-scores/exam-scores.csv into a Pandas DataFrame

It should then ask for two user inputs:
 A Class Section (example: M01 or M02)
 An Exam version (A, B, C, or D)

It should ONLY accept those values for Class Section and Exam Version. Any other inputs and it should print 'Invalid Entry' and not display the data frame.

With valid inputs it should filter the DataFrame to only those rows matching the input (for example section M01, version A)
And display only the Student Score and Letter Grade for each student matching the inputs.

HINT: The very last line in your code should output the dataframe variable. Set it to None in the case of invalid inputs.
'''

# TODO: Write Todo list then beneath write your code


# Write code here 
