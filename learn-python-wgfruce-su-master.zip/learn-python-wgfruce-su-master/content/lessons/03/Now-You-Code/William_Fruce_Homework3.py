'''
Now You Code 3: Distance Conversions

Write a Python program to enter a distnace in feet then convert that
distance to yards and miles. 

For example:

    Enter distance in FEET:15000
    That's 5000.0 yards or 2.8

NOTES:
    - Research the converion formulas on your own.
    - Format output to one decimal place

Start out your program by writing your TODO list of steps
you'll need to solve the problem!
'''

# TODO: Write Todo list then beneath write your code
#Input distance in feet
#Convert feet to yards and miles
#Print yards and miles

distance_feet = int(input('Enter distance in Feet: '))
feet_yards = (distance_feet/3)
feet_miles = (distance_feet*(1/5280))
print('That is %.1f yards or %.1f'% (feet_yards, feet_miles))
