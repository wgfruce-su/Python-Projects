import math # you need this to use math.ceil() 
# Code Here
length = int(input('Enter length of the room: '))
width = int(input('Enter width of the room: '))
height = int(input('Enter height of the room: '))
area = (length+width)*(2*height)
total_gallons = math.ceil(area/400)
print('Total area to be painted: %.2f'%area)
print('Total gallons required: ', total_gallons)
