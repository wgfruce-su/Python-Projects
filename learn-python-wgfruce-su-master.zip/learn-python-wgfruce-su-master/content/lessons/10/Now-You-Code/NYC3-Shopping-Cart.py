'''
Now You Code 3: Shopping Cart

In this program you will implement an online shopping cart using a
Python list of dictionary.

The program should start by allowing the user to enter:
 - Product name
 - Product price
 - Product quantity

until the user enters a product name of 'checkout'

after checkout the program should show the items in the cart
and the total amount of the order (sum of quantity times price)

NOTE: Don't worry about handling bad inputs.

Example Run:

E-Commerce Shopping Cart
Enter product name or 'checkout':pencil
Enter pencil Price:0.99
Enter pencil Quantity:10
Enter product name or 'checkout':calculator
Enter calculator Price:9.99
Enter calculator Quantity:1
Enter product name or 'checkout':checkout
pencil 10 $0.99
calculator 1 $9.99
TOTAL: $19.89

Start out your program by writing your TODO list of steps
you'll need to solve the problem!
'''

# TODO: Write Todo list then beneath write your code


# Write code here 
                           
                                
                      
    
    
